/*
 * Gijs van Horn 10070370
 * Jeroen Vranken 10658491
 * Assignment 2
 */

public interface Compressable {
    int calcIndex(String key);
    void updateHashSize(int size);
}
